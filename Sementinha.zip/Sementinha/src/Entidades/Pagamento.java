package Entidades;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

public class Pagamento {
    private int idTransacao;
    private PessoaFisica pagador;
    private Campanha destino;
    private double valor;
    private String formaPagamento;
    private LocalDateTime dataTransacao;

    //Constructor vazio
    public Pagamento() {
    }

    //Constructor completo
    public Pagamento(int idTransacao, PessoaFisica pagador, Campanha destino, double valor, String formaPagamento, LocalDateTime dataTransacao) {
        this.idTransacao = idTransacao;
        this.pagador = pagador;
        this.destino = destino;
        this.valor = valor;
        this.formaPagamento = formaPagamento;
        this.dataTransacao = dataTransacao;
    }


    //Métodos
    //faz um pagamento à uma determinada campanha
    public static Pagamento fazerPagamento(PessoaFisica pagador, Campanha destino, double valor, String formaPagamento) {
        if (pagador == null || destino == null || formaPagamento.isEmpty() || valor <= 0) {
            throw new IllegalArgumentException("Dados inválidos para pagamento.");
        }
        Pagamento pagamento = new Pagamento(gerarId(), pagador, destino, valor, formaPagamento, LocalDateTime.now());

        Doacao doacao = new Doacao(gerarId(), pagador, LocalDate.now(), valor, destino, pagamento);
        destino.getDoacoes().add(doacao);
        destino.setValorFinal(destino.getValorFinal() + valor);

        return pagamento;
    }

    //Exibe detalhes do pagamento
    public void exibirDetalhesDoPagamento() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        String dataFormatada = dataTransacao.format(formatter);

        System.out.println("Detalhes do pagamento:");
        System.out.println("ID da transação: " + idTransacao);
        System.out.println("Pagador: " + pagador.getNome());
        System.out.println("CPF do Pagador: " + pagador.getCpf());
        System.out.println("Destino: " + destino.getNome());
        System.out.println("Valor: R$ " + valor);
        System.out.println("Data da transação: " + dataFormatada);
        System.out.println("Forma de pagamento: " + formaPagamento);
    }

    //Gera um id do pagamento
    private static int gerarId() {
        return (int) (Math.random() * 10000);
    }

    //Getters e Setters
    public int getIdTransacao() {
        return idTransacao;
    }

    public void setIdTransacao(int idTransacao) {
        this.idTransacao = idTransacao;
    }

    public PessoaFisica getPagador() {
        return pagador;
    }

    public void setPagador(PessoaFisica pagador) {
        this.pagador = pagador;
    }

    public Campanha getDestino() {
        return destino;
    }

    public void setDestino(Campanha destino) {
        this.destino = destino;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public LocalDateTime getDataTransacao() {
        return dataTransacao;
    }

    public void setDataTransacao(LocalDateTime dataTransacao) {
        this.dataTransacao = dataTransacao;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pagamento pagamento = (Pagamento) o;
        return getIdTransacao() == pagamento.getIdTransacao() && Double.compare(getValor(), pagamento.getValor()) == 0 && Objects.equals(getPagador(), pagamento.getPagador()) && Objects.equals(getDestino(), pagamento.getDestino()) && Objects.equals(getFormaPagamento(), pagamento.getFormaPagamento()) && Objects.equals(getDataTransacao(), pagamento.getDataTransacao());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdTransacao(), getPagador(), getDestino(), getValor(), getFormaPagamento(), getDataTransacao());
    }

    //toString
    @Override
    public String toString() {
        return "Pagamento{" +
                "idTransacao=" + idTransacao +
                ", pagador=" + pagador +
                ", destino=" + destino +
                ", valor=" + valor +
                ", formaPagamento='" + formaPagamento + '\'' +
                ", dataTransacao=" + dataTransacao +
                '}';
    }
}
