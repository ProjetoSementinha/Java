package Entidades;

import java.util.Objects;

public class PessoaFisica extends Usuario{
    private String cpf;

    //Constructor vazio
    public PessoaFisica() {
    }

    //Constructor completo
    public PessoaFisica(int id, String nome, String email, String senha, String tipo, String cpf) {
        super(id, nome, email, senha, tipo);
        this.cpf = cpf;
    }

    //Getters e Setters
    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        PessoaFisica that = (PessoaFisica) o;
        return Objects.equals(getCpf(), that.getCpf());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getCpf());
    }

    //toString
    @Override
    public String toString() {
        return "PessoaFisica{" +
                "cpf='" + cpf + '\'' +
                "} " + super.toString();
    }
}
