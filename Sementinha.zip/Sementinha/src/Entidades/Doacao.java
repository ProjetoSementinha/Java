package Entidades;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

public class Doacao {
    private int idDoacao;
    private Usuario doador;
    private LocalDate dataDoacao;
    private double valor;
    private Campanha destinoDoacao;
    private Pagamento pagamento;

    //Constructor vazio
    public Doacao() {
    }

    //Constructor completo
    public Doacao(int idDoacao, Usuario doador, LocalDate dataDoacao, double valor, Campanha destinoDoacao, Pagamento pagamento) {
        this.idDoacao = idDoacao;
        this.doador = doador;
        this.dataDoacao = dataDoacao;
        this.valor = valor;
        this.destinoDoacao = destinoDoacao;
        this.pagamento = pagamento;
    }

    //Métodos
    public void exibirDetalhes() {
        System.out.println("ID da doação: " + idDoacao);
        System.out.println("Doador: " + doador.getNome());
        System.out.println("Valor da doação: R$ " + valor);
        System.out.println("Campanha: " + destinoDoacao.getNome());
        System.out.println("Data da doação: " + dataDoacao.toString());
        if (pagamento != null) {
            pagamento.exibirDetalhesDoPagamento();
        }
    }

    //Getters e Setters
    public int getIdDoacao() {
        return idDoacao;
    }

    public void setIdDoacao(int idDoacao) {
        this.idDoacao = idDoacao;
    }

    public Usuario getDoador() {
        return doador;
    }

    public void setDoador(Usuario doador) {
        this.doador = doador;
    }

    public LocalDate getDataDoacao() {
        return dataDoacao;
    }

    public void setDataDoacao(LocalDate dataDoacao) {
        this.dataDoacao = dataDoacao;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public Campanha getDestinoDoacao() {
        return destinoDoacao;
    }

    public void setDestinoDoacao(Campanha destinoDoacao) {
        this.destinoDoacao = destinoDoacao;
    }

    public Pagamento getPagamento() {
        return pagamento;
    }

    public void setPagamento(Pagamento pagamento) {
        this.pagamento = pagamento;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Doacao doacao = (Doacao) o;
        return getIdDoacao() == doacao.getIdDoacao() && Double.compare(getValor(), doacao.getValor()) == 0 && Objects.equals(getDoador(), doacao.getDoador()) && Objects.equals(getDataDoacao(), doacao.getDataDoacao()) && Objects.equals(getDestinoDoacao(), doacao.getDestinoDoacao()) && Objects.equals(getPagamento(), doacao.getPagamento());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdDoacao(), getDoador(), getDataDoacao(), getValor(), getDestinoDoacao(), getPagamento());
    }

    //toString
    @Override
    public String toString() {
        return "Doacao{" +
                "idDoacao=" + idDoacao +
                ", doador=" + doador +
                ", dataDoacao=" + dataDoacao +
                ", valor=" + valor +
                ", destinoDoacao=" + destinoDoacao +
                ", pagamento=" + pagamento +
                '}';
    }
}
