package Entidades;

import javax.swing.plaf.basic.BasicTreeUI;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class Feed {
    private List<Campanha> campanhas;

    //Constructor vazio
    public Feed() {
    }

    //Constructor completo
    public Feed(List<Campanha> campanhas) {
        this.campanhas = new ArrayList<>();
    }

    //Métodos
    public void adicionarCampanha(Campanha campanha) {
        this.campanhas.add(campanha);
    }

    public void removerCampanha(Campanha campanha) {
        this.campanhas.remove(campanha);
    }

    public void exibirCampanhas() {
        if (campanhas.isEmpty()) {
            System.out.println("Não há campanhas no feed.");
        } else {
            System.out.println("Campanhas no feed:");
            for (Campanha campanha : campanhas) {
                System.out.println("Nome: " + campanha.getNome());
                System.out.println("Descrição: " + campanha.getDescricao());
                System.out.println("Objetivo: " + campanha.getObjetivo());
                System.out.println("Tipo de organização: " + campanha.getOrganizacao().getTipoOrganizacao());
                System.out.println("Categoria: " + campanha.getCategoria());
                System.out.println("-------------");
            }
        }
    }

    public List<Campanha> getCampanhasPorPessoaJuridica(PessoaJuridica organizacao) {
        System.out.println("Campanhas da " + organizacao.getTipoOrganizacao() + " " + organizacao.getNome() + ":");

        List<Campanha> campanhasDaOrganizacao = campanhas.stream()
                .filter(c -> c.getOrganizacao().equals(organizacao))
                .collect(Collectors.toList());

        for (Campanha campanha : campanhasDaOrganizacao) {
            System.out.println("\nCampanha: " + campanha.getNome());
            System.out.println("Descrição: " + campanha.getDescricao());
            System.out.println("Categoria: Energia " + campanha.getCategoria());
        }
        return campanhasDaOrganizacao;
    }

    public List<Campanha> getCampanhasPorCategoria(String categoria) {
        List<Campanha> campanhasPorCategoria = campanhas.stream()
                .filter(c -> c.getCategoria().equalsIgnoreCase(categoria))
                .collect(Collectors.toList());
        for (Campanha campanha : campanhasPorCategoria) {
            System.out.println(campanha.getNome());
        } return campanhas;
    }

    public List<Campanha> getCampanhasMaisProximasDaMeta() {
        return campanhas.stream()
                .sorted(Comparator.comparingDouble(c -> Math.abs(c.getValorFinal() - c.getValorTotalArrecadado())))
                .collect(Collectors.toList());
    }

    public void exibirDetalhesCampanhasMaisProximasDaMeta() {
        List<Campanha> campanhasOrdenadas = getCampanhasMaisProximasDaMeta();
        for (Campanha campanha : campanhasOrdenadas) {
            double progresso = (campanha.getValorTotalArrecadado() / campanha.getValorFinal()) * 100;
            System.out.println("Campanha: " + campanha.getNome());
            System.out.println("Meta: R$ " + campanha.getValorFinal());
            System.out.println("Arrecadado: R$ " + campanha.getValorTotalArrecadado());
            System.out.println("Progresso: " + String.format("%.2f", progresso) + "%");
            System.out.println();
        }
    }

    //Getters e Setters
    public List<Campanha> getCampanhas() {
        return campanhas;
    }

    public void setCampanhas(List<Campanha> campanhas) {
        this.campanhas = campanhas;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Feed feed = (Feed) o;
        return Objects.equals(getCampanhas(), feed.getCampanhas());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getCampanhas());
    }

    //toString
    @Override
    public String toString() {
        return "Feed{" +
                "campanhas=" + campanhas +
                '}';
    }
}
