package Entidades;

import javax.swing.plaf.basic.BasicTreeUI;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class Feed {
    private List<Campanha> campanhas;

    //Constructor vazio
    public Feed() {
    }

    //Constructor completo
    public Feed(List<Campanha> campanhas) {
        this.campanhas = new ArrayList<>();
    }

    //Métodos
    public void adicionarCampanha(Campanha campanha) {
        this.campanhas.add(campanha);
    }

    public void removerCampanha(Campanha campanha) {
        this.campanhas.remove(campanha);
    }

    public List<Campanha> getCampanhasPorPessoaJuridica(PessoaJuridica organizacao) {
        return campanhas.stream()
                .filter(c -> c.getOrganizacao().equals(organizacao))
                .collect(Collectors.toList());
    }

    public List<Campanha> getCampanhasPorCategoria(String categoria) {
        return campanhas.stream()
                .filter(c -> c.getCategoria().equalsIgnoreCase(categoria))
                .collect(Collectors.toList());
    }

    public List<Campanha> getCampanhasMaisProximasDaMeta() {
        return campanhas.stream()
                .sorted((c1, c2) -> {
                    double progresso1 = (c1.getValorInicial() / c1.getValorFinal()) * 100;
                    double progresso2 = (c2.getValorInicial() / c2.getValorFinal()) * 100;
                    return Double.compare(progresso1, progresso2);
                })
                .collect(Collectors.toList());
    }


    public void exibirDetalhesCampanhasMaisProximasDaMeta() {
        List<Campanha> campanhasOrdenadas = getCampanhasMaisProximasDaMeta();
        for (Campanha campanha : campanhasOrdenadas) {
            double progresso = (campanha.getValorInicial() / campanha.getValorFinal()) * 100;
            System.out.println("Campanha: " + campanha.getNome());
            System.out.println("Meta: R$ " + campanha.getValorFinal());
            System.out.println("Arrecadado: R$ " + campanha.getValorInicial());
            System.out.println("Progresso: " + String.format("%.2f", progresso) + "%");
            System.out.println();
        }
    }

    //Getters e Setters
    public List<Campanha> getCampanhas() {
        return campanhas;
    }

    public void setCampanhas(List<Campanha> campanhas) {
        this.campanhas = campanhas;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Feed feed = (Feed) o;
        return Objects.equals(getCampanhas(), feed.getCampanhas());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getCampanhas());
    }

    //toString
    @Override
    public String toString() {
        return "Feed{" +
                "campanhas=" + campanhas +
                '}';
    }
}
