import Entidades.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static Entidades.Menu.adcionarDoacaoComScanner;

public class Main {
    public static void main(String[] args) {
        GerenciadorDeUsuario gerenciadorDeUsuario = new GerenciadorDeUsuario();
        Feed feed = new Feed(new ArrayList<Campanha>());

        //Cadastrando usuários no sistema
        gerenciadorDeUsuario.cadastrarUsuario(1, "Ana", "anamaria@gmail.com", "12345", "Pessoa Física", "51746481838");
        gerenciadorDeUsuario.cadastrarUsuario(2, "EcoTech", "marlene@gmail.com","5674485", "Pessoa Jurídica", "12.345.678/0001-99", "Rua Verde", "Empresa");
        gerenciadorDeUsuario.cadastrarUsuario(1, "Ana", "anamaria@gmail.com", "12345", "Pessoa Física", "51746481838");

        List<Usuario> usuarios = gerenciadorDeUsuario.getUsuarios();
        PessoaFisica pessoa1 = (PessoaFisica) usuarios.get(0);
        PessoaJuridica pessoa2 = (PessoaJuridica) usuarios.get(1);

        System.out.println("Vamos criar uma nova campanha para a empresa: " + pessoa2.getNome());
        Campanha novaCampanha = pessoa2.criarCampanhaComScanner();
        feed.adicionarCampanha(novaCampanha);
        for (Campanha campanha : feed.getCampanhas()) {
            campanha.exibirDetalhes();
            System.out.println();
        }

        //Adicionando uma doação através do scanner
        System.out.println("Adicionando doações à campanha: ");
        adcionarDoacaoComScanner(novaCampanha);

        //Adicionando uma doação de forma manual
        Doacao doacao1 = new Doacao(pessoa1, LocalDate.now(), 50.00, novaCampanha);;
        novaCampanha.adicionarDoacao(doacao1.getValor());

        for (Campanha campanha : feed.getCampanhas()) {
            System.out.println();
        }
    }
}