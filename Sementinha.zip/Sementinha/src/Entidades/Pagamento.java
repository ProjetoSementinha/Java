package Entidades;

import java.time.LocalDateTime;
import java.util.Objects;

public class Pagamento {
    private int idTransacao;
    private Usuario pagador;
    private Campanha destino;
    private double valor;
    private String formaPagamento;
    private LocalDateTime dataTransacao;

    //Constructor vazio
    public Pagamento() {
    }

    //Constructor completo
    public Pagamento(int idTransacao, Usuario pagador, Campanha destino, double valor, String formaPagamento, LocalDateTime dataTransacao) {
        this.idTransacao = idTransacao;
        this.pagador = pagador;
        this.destino = destino;
        this.valor = valor;
        this.formaPagamento = formaPagamento;
        this.dataTransacao = dataTransacao;
    }

    //Métodos

    //Getters e Setters
    public int getIdTransacao() {
        return idTransacao;
    }

    public void setIdTransacao(int idTransacao) {
        this.idTransacao = idTransacao;
    }

    public Usuario getPagador() {
        return pagador;
    }

    public void setPagador(Usuario pagador) {
        this.pagador = pagador;
    }

    public Campanha getDestino() {
        return destino;
    }

    public void setDestino(Campanha destino) {
        this.destino = destino;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public LocalDateTime getDataTransacao() {
        return dataTransacao;
    }

    public void setDataTransacao(LocalDateTime dataTransacao) {
        this.dataTransacao = dataTransacao;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pagamento pagamento = (Pagamento) o;
        return getIdTransacao() == pagamento.getIdTransacao() && Double.compare(getValor(), pagamento.getValor()) == 0 && Objects.equals(getPagador(), pagamento.getPagador()) && Objects.equals(getDestino(), pagamento.getDestino()) && Objects.equals(getFormaPagamento(), pagamento.getFormaPagamento()) && Objects.equals(getDataTransacao(), pagamento.getDataTransacao());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getIdTransacao(), getPagador(), getDestino(), getValor(), getFormaPagamento(), getDataTransacao());
    }

    //toString
    @Override
    public String toString() {
        return "Pagamento{" +
                "idTransacao=" + idTransacao +
                ", pagador=" + pagador +
                ", destino=" + destino +
                ", valor=" + valor +
                ", formaPagamento='" + formaPagamento + '\'' +
                ", dataTransacao=" + dataTransacao +
                '}';
    }
}
