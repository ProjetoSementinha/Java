package Entidades;

import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class PessoaJuridica extends Usuario {
    private String cnpj;
    private String endereco;
    private String tipo;

    //Constructor vazio
    public PessoaJuridica() {
    }

    //Constructor completo
    public PessoaJuridica(int id, String nome, String email, String senha, String tipo, String cnpj, String endereco, String tipoP) {
        super(id, nome, email, senha, tipo);
        this.cnpj = cnpj;
        this.endereco = endereco;
        this.tipo = tipoP;
    }

    //Métodos
    public Campanha criarCampanha(String nome, String descricao, String objetivo, double valorInicial, double valorTotalArrecadado,double valorFinal, String categoria) {
        return new Campanha(this, nome, descricao, objetivo, valorInicial, valorTotalArrecadado, valorFinal, categoria);
    }

    // Metodo para criar campanha usando Scanner
    public Campanha criarCampanhaComScanner() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o nome da campanha:");
        String nome = scanner.nextLine();

        System.out.println("Digite a descrição da campanha:");
        String descricao = scanner.nextLine();

        System.out.println("Digite o objetivo da campanha:");
        String objetivo = scanner.nextLine();

        System.out.println("Digite o valor inicial da campanha:");
        double valorInicial = scanner.nextDouble();
        scanner.nextLine();

        System.out.println("Digite o valor total arrecadado até agora:");
        double valorTotalArrecadado = scanner.nextDouble();
        scanner.nextLine();

        System.out.println("Digite o valor final da campanha:");
        double valorFinal = scanner.nextDouble();
        scanner.nextLine();

        System.out.println("Digite a categoria da campanha (Eolica, Solar ou Nuclear): ");
        String categoria = scanner.nextLine();

        return new Campanha(this, nome, descricao, objetivo, valorInicial, valorTotalArrecadado, valorFinal, categoria);
    }

    public void processarEmailDoDoador(String email) {
        System.out.println("E-mail do doador: " + email + "enviado para a organização: " + this.getNome());
        // Aqui você pode adicionar a lógica de envio de e-mail, registro no sistema da organização, etc.
    }

    //Getters e Setters
    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    @Override
    public String getTipo() {
        return tipo;
    }

    @Override
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        PessoaJuridica that = (PessoaJuridica) o;
        return Objects.equals(getCnpj(), that.getCnpj()) && Objects.equals(getEndereco(), that.getEndereco()) && Objects.equals(getTipo(), that.getTipo());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getCnpj(), getEndereco(), getTipo());
    }

    //toString
    @Override
    public String toString() {
        return "PessoaJuridica{" +
                "cnpj='" + cnpj + '\'' +
                ", endereco='" + endereco + '\'' +
                ", tipo='" + tipo + '\'' +
                "} " + super.toString();
    }
}
