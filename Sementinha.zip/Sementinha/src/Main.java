import Entidades.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Criação do gerenciador, feed e menu
        GerenciadorDeUsuario gerenciadorDeUsuario = new GerenciadorDeUsuario();
        Feed feed = new Feed(new ArrayList<Campanha>());
        Menu menu = new Menu();

        //Criação de usuários
        PessoaFisica doador = new PessoaFisica(gerenciadorDeUsuario.gerarIdUsuario(), "Beatriz", "beatriz@gmail.com", "4735643", "Pessoa Física", "6785378889");
        PessoaJuridica organizacao1 = new PessoaJuridica(gerenciadorDeUsuario.gerarIdUsuario(), "FIA", "fia@gmail.com", "fia6753", "Pessoa Jurídica", "15.875.699/0005-77", "Alameda dos Saíras, 78", "Empresa");
        PessoaJuridica organizacao2 = new PessoaJuridica(gerenciadorDeUsuario.gerarIdUsuario(), "SAP", "sap@gmail.com", "sap1478", "Pessoa Jurídica", "81.612.988/0007-99", "Rua Coronel Evaristo de Campos, 131", "Ong");
        PessoaJuridica organizacao3 = new PessoaJuridica(gerenciadorDeUsuario.gerarIdUsuario(), "Ultragaz", "ultragaz@gmail.com", "ultragaz7766", "Pessoa Jurídica", "56.135.430/0001-45", "Avenida Leôncio de Magalhães, 56", "Empresa");

        //Criando e adicionando uma campanha pelo sistema
        Campanha campanha1 = new Campanha(organizacao1, "FIA - “E-Racing Green Circuit”", "A FIA apresenta a campanha E-Racing Green Circuit, um projeto inovador para criar pistas de corrida sustentáveis alimentadas por energia eólica. O objetivo é reduzir as emissões de carbono dos eventos de corrida e promover a energia limpa no esporte automobilístico.", "promover a energia limpa no esporte", 0.0, 0.0, 250000.0, "Eólica", new ArrayList<Doacao>());
        feed.adicionarCampanha(campanha1);

        //Adicionando usuários ao gerenciador de usuário
        gerenciadorDeUsuario.adicionarUsuario(doador);
        gerenciadorDeUsuario.adicionarUsuario(organizacao1);
        gerenciadorDeUsuario.adicionarUsuario(organizacao2);
        gerenciadorDeUsuario.adicionarUsuario(organizacao3);

        //Eibe o menu com todas funções
        System.out.println("\n---------------------------");
        menu.exibirMenu(feed, organizacao1, doador, campanha1, gerenciadorDeUsuario);


    }
}