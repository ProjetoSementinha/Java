package Entidades;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class Campanha {
    private PessoaJuridica organizacao;
    private String nome;
    private String descricao;
    private String objetivo;
    private double valorInicial;
    private double valorTotalArrecadado;
    private double valorFinal;
    private String categoria;
    private List<Doacao> doacoes;

    //Constructor vazio
    public Campanha() {
    }

    //Constructor completo
    public Campanha(PessoaJuridica organizacao, String nome, String descricao, String objetivo, double valorInicial, double valorTotalArrecadado, double valorFinal, String categoria, List<Doacao> doacoes) {
        this.organizacao = organizacao;
        this.nome = nome;
        this.descricao = descricao;
        this.objetivo = objetivo;
        this.valorInicial = valorInicial;
        this.valorTotalArrecadado = valorTotalArrecadado;
        this.valorFinal = valorFinal;
        this.categoria = categoria;
        this.doacoes = doacoes;
    }

    //Métodos
    public void exibirDetalhes() {
        System.out.println("Campanha: " + nome);
        System.out.println("Descrição: " + descricao);
        System.out.println("Objetivo: " + objetivo);
        System.out.println("Valor Inicial: R$ " + valorInicial);
        System.out.println("Valor arrecadado até agora: R$ " + valorTotalArrecadado);
        System.out.println("Valor Final: R$ " + valorFinal);
        System.out.println("Categoria: " + categoria);
        System.out.println("Organização: " + organizacao.getNome() + " (" + organizacao.getTipo() + ")");
        System.out.println("Progresso: " + String.format("%.2f", calcularProgresso()) + "%");
    }

    public void adicionarDoacao(double valorDoacao) {
        valorTotalArrecadado += valorDoacao;
    }

    public double calcularProgresso() {
        return (valorTotalArrecadado / valorFinal) * 100;
    }

    //Getters e Setters
    public PessoaJuridica getOrganizacao() {
        return organizacao;
    }

    public void setOrganizacao(PessoaJuridica organizacao) {
        this.organizacao = organizacao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getObjetivo() {
        return objetivo;
    }

    public void setObjetivo(String objetivo) {
        this.objetivo = objetivo;
    }

    public double getValorInicial() {
        return valorInicial;
    }

    public void setValorInicial(double valorInicial) {
        this.valorInicial = valorInicial;
    }

    public double getValorTotalArrecadado() {
        return valorTotalArrecadado;
    }

    public void setValorTotalArrecadado(double valorTotalArrecadado) {
        this.valorTotalArrecadado = valorTotalArrecadado;
    }

    public double getValorFinal() {
        return valorFinal;
    }

    public void setValorFinal(double valorFinal) {
        this.valorFinal = valorFinal;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public List<Doacao> getDoacoes() {
        return doacoes;
    }

    public void setDoacoes(List<Doacao> doacoes) {
        this.doacoes = doacoes;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Campanha campanha = (Campanha) o;
        return Double.compare(getValorInicial(), campanha.getValorInicial()) == 0 && Double.compare(getValorTotalArrecadado(), campanha.getValorTotalArrecadado()) == 0 && Double.compare(getValorFinal(), campanha.getValorFinal()) == 0 && Objects.equals(getOrganizacao(), campanha.getOrganizacao()) && Objects.equals(getNome(), campanha.getNome()) && Objects.equals(getDescricao(), campanha.getDescricao()) && Objects.equals(getObjetivo(), campanha.getObjetivo()) && Objects.equals(getCategoria(), campanha.getCategoria()) && Objects.equals(getDoacoes(), campanha.getDoacoes());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getOrganizacao(), getNome(), getDescricao(), getObjetivo(), getValorInicial(), getValorTotalArrecadado(), getValorFinal(), getCategoria(), getDoacoes());
    }

    //toString
    @Override
    public String toString() {
        return "Campanha{" +
                "organizacao=" + organizacao +
                ", nome='" + nome + '\'' +
                ", descricao='" + descricao + '\'' +
                ", objetivo='" + objetivo + '\'' +
                ", valorInicial=" + valorInicial +
                ", valorTotalArrecadado=" + valorTotalArrecadado +
                ", valorFinal=" + valorFinal +
                ", categoria='" + categoria + '\'' +
                ", doacoes=" + doacoes +
                '}';
    }
}
