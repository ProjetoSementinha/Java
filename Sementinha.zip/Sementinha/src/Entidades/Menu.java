package Entidades;

import java.awt.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;

public class Menu {
    public void exibirMenu(Feed feed, PessoaJuridica organizacao, PessoaFisica doador, Campanha campanha, GerenciadorDeUsuario gerenciadorDeUsuario) {
        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("\n--- Menu ---");
            System.out.println("1. Cadastrar Pessoa Física (Doador)");
            System.out.println("2. Cadastrar Pessoa Jurídica (Organização)");
            System.out.println("3. Criar campanha");
            System.out.println("4. Exibir campanhas disponíveis");
            System.out.println("5. Fazer uma doação");
            System.out.println("6. Obter lista de usuários no sistema");
            System.out.println("7. Lista de usuários: Pessoa Física");
            System.out.println("8. Lista de usuários: Pessoa Jurídica");
            System.out.println("9. Lista de ONGs");
            System.out.println("10. Lista de Empresas");
            System.out.println("11. Campanhas mais próximas da meta");
            System.out.println("12. Filtrar campanhas por: Energia Eólica");
            System.out.println("13. Listar campanhas por organização: FIA");
            System.out.println("14. Sair");
            System.out.println("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    cadastrarPessoaFisica(gerenciadorDeUsuario, doador.getId(), doador.getTipo());
                    break;
                case 2:
                    cadastrarPessoaJuridica(gerenciadorDeUsuario, organizacao.getId(), organizacao.getTipo());
                    break;
                case 3:
                    criarCampanha(feed, organizacao);
                    break;
                case 4:
                    feed.exibirCampanhas();
                    break;
                case 5:
                    feed.exibirCampanhas();
                    exibirCampanhasDisponiveis(feed, doador);
                    break;
                case 6:
                    System.out.println("Lista de usuários: ");
                    gerenciadorDeUsuario.getListaDeUsuarios().forEach(System.out::println);
                    System.out.println(gerenciadorDeUsuario.quantidadeDeUsuarios());
                    break;
                case 7:
                    System.out.println("Lista de usuários ordenados por tipo: Pessoa Física");
                    gerenciadorDeUsuario.getListDeUsuariosPorTipo("Pessoa Física");
                    break;
                case 8:
                    System.out.println("Lista de usuários ordenados por tipo: Pessoa Jurídica");
                    gerenciadorDeUsuario.getListDeUsuariosPorTipo("Pessoa Jurídica");
                    break;
                case 9:
                    gerenciadorDeUsuario.getListaDeOrganizacaoPorTipo("Ong");
                    break;
                case 10:
                    gerenciadorDeUsuario.getListaDeOrganizacaoPorTipo("Empresa");
                    break;
                case 11:
                    System.out.println("Campanhas  mais próximas de atingir a meta:");
                    feed.exibirDetalhesCampanhasMaisProximasDaMeta();
                    break;
                case 12:
                    System.out.println("Campanhas sustentáveis disponíveis da categoria: Energia Eólica ");
                    feed.getCampanhasPorCategoria("eólica");
                    break;
                case 13:
                    System.out.println("Campanhas criadas pela Organização FIA: ");
                    feed.getCampanhasPorPessoaJuridica(organizacao);
                    break;
                case 14:
                    System.out.println("Saindo do sistema.");
                    break;
                default:
                    System.out.println("Operação inválida. Tente novamente.");
            }
        } while (opcao != 14);
    }

    // Método para cadastrar usuário do tipo Pessoa Física com scanner
    public void cadastrarPessoaFisica(GerenciadorDeUsuario gerenciadorDeUsuario,int id, String tipo) {
        System.out.println("Faça seu cadastro: ");
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite seu nome de usuário: ");
        String nome = scanner.nextLine();

        System.out.println("Digite seu e-mail: ");
        String email = scanner.nextLine();

        System.out.println("Digite sua senha: ");
        String senha = scanner.nextLine();

        System.out.println("Digite seu CPF: ");
        String cpf = scanner.nextLine();

        PessoaFisica pessoaFisica = new PessoaFisica(id, nome, email, senha, tipo, cpf);
        gerenciadorDeUsuario.cadastrarUsuario(pessoaFisica);
    }

    // Método para cadastrar usuário do tipo Pessoa Jurídica com scanner
    public void cadastrarPessoaJuridica(GerenciadorDeUsuario gerenciadorDeUsuario, int id, String tipo) {
        System.out.println("Faça seu cadastro: ");
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite a Razão Social da Empresa/Ong: ");
        String razaoSocial = scanner.nextLine();

        System.out.println("Digite o e-mail da Organização: ");
        String email = scanner.nextLine();

        System.out.println("Digite a senha da conta: ");
        String senha = scanner.nextLine();

        System.out.println("Digite o CNPJ da Organização: ");
        String cnpj = scanner.nextLine();

        System.out.println("Digite o endereço da Organização: ");
        String endereco = scanner.nextLine();

        System.out.println("Digite o tipo de Organização (Empresa/Ong): ");
        String tipoOrganizacao = scanner.nextLine();

        PessoaJuridica pessoaJuridica = new PessoaJuridica(id, razaoSocial, email, senha, tipo, cnpj, endereco, tipoOrganizacao);
        gerenciadorDeUsuario.cadastrarUsuario(pessoaJuridica);
    }

    // Metodo para criar campanha usando Scanner
    public void criarCampanha(Feed feed, PessoaJuridica organizacao) {
        System.out.println("Vamos criar uma nova campanha para a "+ organizacao.getTipoOrganizacao() + " " + organizacao.getNome());
        Scanner scanner = new Scanner(System.in);
        boolean continuar = true;

        while (continuar) {
            System.out.println("Digite o nome da campanha:");
            String nome = scanner.nextLine();

            System.out.println("Digite a descrição da campanha:");
            String descricao = scanner.nextLine();

            System.out.println("Digite o objetivo da campanha:");
            String objetivo = scanner.nextLine();

            System.out.println("Digite o valor inicial da campanha:");
            double valorInicial = scanner.nextDouble();
            scanner.nextLine();

            System.out.println("Digite o valor total arrecadado até agora:");
            double valorTotalArrecadado = scanner.nextDouble();
            scanner.nextLine();

            System.out.println("Digite o valor final da campanha:");
            double valorFinal = scanner.nextDouble();
            scanner.nextLine();

            System.out.println("Digite a categoria da campanha (tipo de energia sustentável): ");
            String categoria = scanner.nextLine();

            Campanha campanha = new Campanha(organizacao, nome, descricao, objetivo, valorInicial, valorTotalArrecadado, valorFinal, categoria, new ArrayList<Doacao>());

            feed.adicionarCampanha(campanha);

            System.out.println("Campanha criada e adicionada ao feed com sucesso!");

            System.out.println("Deseja adicionar outra campanha? (s/n)");
            String resposta = scanner.nextLine();

            if (!resposta.equalsIgnoreCase("s")) {
                continuar = false;
            }
        }
        feed.exibirCampanhas();
    }

    public void exibirCampanhasDisponiveis(Feed feed, PessoaFisica doador) {
        Scanner scanner = new Scanner(System.in);

        //Pergunta se o usuário deseja fazer uma doação para alguma campanha
        System.out.println("Você deseja fazer uma doação para alguma dessas campanhas? (s/n)");
        String resposta = scanner.nextLine();

        if (resposta.equalsIgnoreCase("n")) {
            System.out.println("Operação encerrada.");
            return;
        }
        if (resposta.equalsIgnoreCase("s")) {
            if (feed.getCampanhas().isEmpty()) {
                System.out.println("Não há campanhas no feed.");
                return;
            }

            //Exibe as campanhas numeradas
            System.out.println("Escolha a campanha para a qual deseja doar, ou 0 para cancelar:");

            for (int i = 0; i < feed.getCampanhas().size(); i++) {
                Campanha campanha = feed.getCampanhas().get(i);
                System.out.println((i + 1) + ". " + campanha.getNome() + " - Objetivo: " + campanha.getObjetivo());
            }

            //Pergunta qual campanha o doador deseja apoiar
            System.out.println("Digite o número da campanha para a qual deseja doar, ou 0 para cancelar:");
            int escolha = scanner.nextInt();
            scanner.nextLine();

            if (escolha == 0) {
                System.out.println("Operação Cancelada.");
                return;
            }
            if (escolha < 1 || escolha > feed.getCampanhas().size()) {
                System.out.println("Escolha inválida");
                return;
            }

            //Obtém a campanha escolhida
            Campanha campanhaEscolhida = feed.getCampanhas().get(escolha - 1);

            //Pergunta se deseja fazer a doação para a campanhaa escolhida
            System.out.println("Você escolheu a campanha " + campanhaEscolhida.getNome()+ ". Deseja fazer uma doação para esta campanha? (s/n)");
            String confirmaDoacao = scanner.nextLine();

            if (confirmaDoacao.equalsIgnoreCase("s")) {
                adicionarDoacao(feed, doador, campanhaEscolhida);
            } else {
                System.out.println("Doação não realizada.");
            }
        }
    }

    //Metodo de adicionar um valor de doação com scanner
    public void adicionarDoacao(Feed feed, PessoaFisica doador, Campanha campanha) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o valor da doação: ");
        double valorDoacao = scanner.nextDouble();
        scanner.nextLine();

        System.out.println("Digite a forma de pagamento: ");
        String formaPagamento = scanner.nextLine();

        Random random = new Random();
        int idTransacao = random.nextInt(1000000);

        Pagamento pagamento = new Pagamento(idTransacao, doador, campanha, valorDoacao, formaPagamento, LocalDateTime.now());

        Doacao doacao = new Doacao(doador.getId(), doador, LocalDate.now(), valorDoacao, campanha, pagamento);
        campanha.adicionarDoacao(doacao.getValor());

        System.out.println("Doação de R$ " + valorDoacao + " enviada para a campanha " + campanha.getNome() + " com sucesso!");
        System.out.println("Forma de pagamento: " + pagamento.getFormaPagamento());
        System.out.println("ID da transação: " + idTransacao);
        System.out.println("Progresso atual da campanha: " + String.format("%.2f", campanha.calcularProgresso()) + "%");
        System.out.println("\nA equipe Sementinha agradece por ajudar a semear um futuro melhor!");
    }
}
