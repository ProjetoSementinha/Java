package Entidades;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class GerenciadorDeUsuario {
    private List<Usuario> usuarios;

    //Constructor vazio
    public GerenciadorDeUsuario() {
        this.usuarios = new ArrayList<>();
    }

    //Constructor completo
    public GerenciadorDeUsuario(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    //Métodos
    //Gera um id dee usuário aleatório
    public int gerarIdUsuario() {
        return (int) (Math.random() * 10000);
    }

    public void adicionarUsuario(Usuario usuario) {
        this.usuarios.add(usuario);
    }

    public void removerUsuario(Usuario usuario) {
        this.usuarios.remove(usuario);
    }

    //pega a lista contendo todos os usuários do sistema
    public List<Usuario> getListaDeUsuarios() {
        return usuarios.stream()
                .collect(Collectors.toList());
    }

    //pega a lista de usuários por um determinado tipo (Pessoa Física ou Pessoa Jurídica)
    public List<Usuario> getListDeUsuariosPorTipo(String tipo) {
        List<Usuario> usuariosPorTipo = usuarios.stream()
                        .filter(u -> u.getTipo().equalsIgnoreCase(tipo))
                        .collect(Collectors.toList());
        for (Usuario usuario : usuariosPorTipo) {
            System.out.println("ID: " + usuario.getId() + " |Nome: " + usuario.getNome() + " |E-mail: " + usuario.getEmail());
        }
        System.out.println("Número de usuários do tipo " + tipo + ": " + usuariosPorTipo.size());
        return usuariosPorTipo;
    }

    //pega a lista de organizações listadas por tipo (Empresa ou Ong) e exibe a quanidad de cada
    public List<PessoaJuridica> getListaDeOrganizacaoPorTipo(String tipoOrganizacao) {
        List<PessoaJuridica> pessoaJuridicasPorOrganizacao = usuarios.stream()
                .filter(u -> u instanceof PessoaJuridica)
                .map(u -> (PessoaJuridica) u)
                .filter(pj -> pj.getTipoOrganizacao().equalsIgnoreCase(tipoOrganizacao))
                .collect(Collectors.toList());

        System.out.println("Número de organizações do tipo '" + tipoOrganizacao + "': " + pessoaJuridicasPorOrganizacao.size());
        for (PessoaJuridica pj : pessoaJuridicasPorOrganizacao) {
            System.out.println("ID: " + pj.getId() + ", Nome: " + pj.getNome() + ", Email: " + pj.getEmail() + ", Tipo de Organização: " + pj.getTipoOrganizacao());
        }
        return pessoaJuridicasPorOrganizacao;
    }

    // Metodo sobrecarga para cadastrar Pessoa Física
    public void cadastrarUsuario(PessoaFisica pessoaFisica) {
        if (emailJaCadastrado(pessoaFisica.getEmail())) {
            System.out.println("Erro: E-mail já cadastrado!");
            return;
        }
        usuarios.add(pessoaFisica);
        System.out.println("Pessoa Física | E-mail " + pessoaFisica.getEmail() + " cadastrado com sucesso!");

    }

    // Metodo sobrecarga para cadastrar Pessoa Jurídica
    public void cadastrarUsuario(PessoaJuridica pessoaJuridica) {
        if (emailJaCadastrado(pessoaJuridica.getEmail())) {
            System.out.println("Erro: E-mail já cadastrado!");
            return;
        }
        usuarios.add(pessoaJuridica);
        System.out.println("Pessoa Júridica | E-mail " + pessoaJuridica.getEmail() + " cadastrado com sucesso!");

    }

    //Verifica se um email já está cadastrado no sistema
    private boolean emailJaCadastrado(String email) {
        return usuarios.stream().anyMatch(u -> u.getEmail().equalsIgnoreCase(email));
    }

    // retorna quantidade de usuários no sistema
    public int quantidadeDeUsuarios() {
        System.out.println("\nQuantidade total de usuários: ");
        return usuarios.size();
    }

    //Getters e Setters
    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GerenciadorDeUsuario that = (GerenciadorDeUsuario) o;
        return Objects.equals(getUsuarios(), that.getUsuarios());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getUsuarios());
    }

    //toString
    @Override
    public String toString() {
        return "GerenciadorDeUsuario{" +
                "usuarios=" + usuarios +
                '}';
    }
}
