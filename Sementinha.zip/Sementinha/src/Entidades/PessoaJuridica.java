package Entidades;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class PessoaJuridica extends Usuario {
    private String cnpj;
    private String endereco;
    private String tipoOrganizacao;

    //Constructor vazio
    public PessoaJuridica() {
    }

    //Constructor completo
    public PessoaJuridica(int id, String nome, String email, String senha, String tipo, String cnpj, String endereco, String tipoOrganizacao) {
        super(id, nome, email, senha, tipo);
        this.cnpj = cnpj;
        this.endereco = endereco;
        this.tipoOrganizacao = tipoOrganizacao;
    }

    //Métodos
    public void processarEmailDoDoador(PessoaFisica pessoaFisica, String email) {
        System.out.println("E-mail do doador: " + pessoaFisica.getEmail() + "enviado para a organização: " + this.getNome());
    }

    //Getters e Setters
    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTipoOrganizacao() {
        return tipoOrganizacao;
    }

    public void setTipoP(String tipoP) {
        this.tipoOrganizacao = tipoP;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        PessoaJuridica that = (PessoaJuridica) o;
        return Objects.equals(getCnpj(), that.getCnpj()) && Objects.equals(getEndereco(), that.getEndereco()) && Objects.equals(tipoOrganizacao, that.tipoOrganizacao);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getCnpj(), getEndereco(), tipoOrganizacao);
    }

    //toString
    @Override
    public String toString() {
        return "Pessoa Jurídica" +
                " |CNPJ: " + cnpj + '\'' +
                " |Endereço: " + endereco + '\'' +
                " |Tipo de organização: " + tipoOrganizacao + '\'' +
                " |" + super.toString();
    }
}
