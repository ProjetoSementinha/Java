package Entidades;

import java.util.Scanner;

public class Menu {
    //Metodo de adicionar um valor de doação com scanner
    public static void adcionarDoacaoComScanner(Campanha campanha) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o valor da doação: ");
        double valorDoacao = scanner.nextDouble();
        scanner.nextLine();

        campanha.adicionarDoacao(valorDoacao);

        System.out.println("Doação de R$ " + valorDoacao + " recebida com sucesso!");
        System.out.println("Progresso: " + String.format("%.2f", campanha.calcularProgresso()) + "%");
    }

    // Metodo para criar campanha usando Scanner
    public static Campanha criarCampanhaComScanner(PessoaJuridica organizacao) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o nome da campanha:");
        String nome = scanner.nextLine();

        System.out.println("Digite a descrição da campanha:");
        String descricao = scanner.nextLine();

        System.out.println("Digite o objetivo da campanha:");
        String objetivo = scanner.nextLine();

        System.out.println("Digite o valor inicial da campanha:");
        double valorInicial = scanner.nextDouble();
        scanner.nextLine();

        System.out.println("Digite o valor total arrecadado até agora:");
        double valorTotalArrecadado = scanner.nextDouble();
        scanner.nextLine();

        System.out.println("Digite o valor final da campanha:");
        double valorFinal = scanner.nextDouble();
        scanner.nextLine();

        System.out.println("Digite a categoria da campanha (Eolica, Solar ou Nuclear): ");
        String categoria = scanner.nextLine();

        return new Campanha(organizacao, nome, descricao, objetivo, valorInicial, valorTotalArrecadado, valorFinal, categoria);
    }
}
