package Entidades;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class GerenciadorDeUsuario {
    private List<Usuario> usuarios;

    //Constructor vazio
    public GerenciadorDeUsuario() {
        this.usuarios = new ArrayList<>();
    }

    //Constructor completo
    public GerenciadorDeUsuario(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    //Métodos
    public boolean isUsuarioCadastrado(String email) {
        for (Usuario usuario : usuarios) {
            if (usuario.getEmail().equals(email)) {
                return true;
            }
        }
        return false;
    }

    public void adicionarUsuario(Usuario usuario) {
        this.usuarios.add(usuario);
    }

    public void removerUsuario(Usuario usuario) {
        this.usuarios.remove(usuario);
    }

    // Método sobrecarga para cadastrar Pessoa Física
    public void cadastrarUsuario(int id, String nome, String email, String senha, String tipo, String cpf) {
        if (emailJaCadastrado(email)) {
            System.out.println("Erro: E-mail já cadastrado!");
        } else {
            PessoaFisica usuario = new PessoaFisica(id, nome, email, senha, tipo, cpf);
            usuarios.add(usuario);
            System.out.println("Usuário Pessoa Física cadastrado com sucesso!");
        }
    }

    // Método sobrecarga para cadastrar Pessoa Jurídica
    public void cadastrarUsuario(int id, String nome, String email, String senha, String tipo, String cnpj, String endereco, String tipoP) {
        if (emailJaCadastrado(email)) {
            System.out.println("Erro: E-mail já cadastrado!");
        } else {
            PessoaJuridica usuario = new PessoaJuridica(id, nome, email, senha, tipo, cnpj, endereco, tipoP);
            usuarios.add(usuario);
            System.out.println("Usuário Pessoa Jurídica cadastrado com sucesso!");
        }
    }

    private boolean emailJaCadastrado(String email) {
        return usuarios.stream().anyMatch(u -> u.getEmail().equals(email));
    }

    //Getters e Setters
    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(List<Usuario> usuarios) {
        this.usuarios = usuarios;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GerenciadorDeUsuario that = (GerenciadorDeUsuario) o;
        return Objects.equals(getUsuarios(), that.getUsuarios());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getUsuarios());
    }

    //toString
    @Override
    public String toString() {
        return "GerenciadorDeUsuario{" +
                "usuarios=" + usuarios +
                '}';
    }
}
