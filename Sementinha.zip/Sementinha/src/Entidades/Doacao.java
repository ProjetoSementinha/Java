package Entidades;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Objects;

public class Doacao {
    private Usuario doador;
    private LocalDate dataDoacao;
    private double valor;
    private Campanha destinoDoacao;

    //Constructor vazio
    public Doacao() {
    }

    //Constructor completo
    public Doacao(Usuario doador, LocalDate dataDoacao, double valor, Campanha destinoDoacao) {
        this.doador = doador;
        this.dataDoacao = dataDoacao;
        this.valor = valor;
        this.destinoDoacao = destinoDoacao;
    }

    //Métodos

    //Getters e Setters
    public Usuario getDoador() {
        return doador;
    }

    public void setDoador(Usuario doador) {
        this.doador = doador;
    }

    public LocalDate getDataDoacao() {
        return dataDoacao;
    }

    public void setDataDoacao(LocalDate dataDoacao) {
        this.dataDoacao = dataDoacao;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public Campanha getDestinoDoacao() {
        return destinoDoacao;
    }

    public void setDestinoDoacao(Campanha destinoDoacao) {
        this.destinoDoacao = destinoDoacao;
    }

    //Equals e HashCode
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Doacao doacao = (Doacao) o;
        return Double.compare(getValor(), doacao.getValor()) == 0 && Objects.equals(getDoador(), doacao.getDoador()) && Objects.equals(getDataDoacao(), doacao.getDataDoacao()) && Objects.equals(getDestinoDoacao(), doacao.getDestinoDoacao());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getDoador(), getDataDoacao(), getValor(), getDestinoDoacao());
    }

    //toString
    @Override
    public String toString() {
        return "Doacao{" +
                "doador=" + doador +
                ", dataDoacao=" + dataDoacao +
                ", valor=" + valor +
                ", destinoDoacao=" + destinoDoacao +
                '}';
    }
}
